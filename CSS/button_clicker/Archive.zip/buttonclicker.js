var likes1 = 0;
function CountUp(element) {
    ++likes1;
    element.innerText = likes1 + " likes";
    alert("Ninja was liked");
}

function hide(element) {
    element.remove();
}

var display = document.getElementById("navbtn");
function LogIn(){
    display.innerText = "Log Out";

}
