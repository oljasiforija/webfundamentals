console.log("page loaded...");

var video = document.getElementById("video");
function PlayVideo(){
    video.play();
    video.muted = false;
}
function StopVideo(){
    video.pause();
    video.muted = true;
}
